import 'package:flutter_test/flutter_test.dart';
import 'package:smartchat/main.dart';

void main() {
  testWidgets('SmartChat app smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(
      const SmartChatApp(),
    );
    expect(find.byType(SmartChatApp), findsOneWidget);
  });
}
