package com.smartchatmessenger.smartchat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
