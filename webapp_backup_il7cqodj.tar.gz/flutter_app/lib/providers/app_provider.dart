import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/chat_model.dart';
import '../models/story_model.dart';
import '../services/api_service.dart';

class AppProvider extends ChangeNotifier {
  UserModel? _currentUser;
  List<ChatModel> _chats = [];
  List<StoryGroup> _stories = [];
  bool _loading = false;
  String? _error;

  UserModel? get currentUser => _currentUser;
  List<ChatModel> get chats => _chats;
  List<StoryGroup> get stories => _stories;
  bool get loading => _loading;
  String? get error => _error;
  bool get isLoggedIn => _currentUser != null;

  int get totalUnread => _chats.fold(0, (sum, c) => sum + c.unreadCount);

  Future<bool> tryAutoLogin() async {
    await ApiService.init();
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('current_user');
    if (saved != null) {
      try {
        _currentUser = UserModel.fromJson(jsonDecode(saved));
        notifyListeners();
        // Verify token is still valid
        final user = await ApiService.getMe();
        _currentUser = user;
        await _saveUser(user);
        notifyListeners();
        return true;
      } catch (_) {
        await ApiService.clearToken();
        _currentUser = null;
        notifyListeners();
        return false;
      }
    }
    return false;
  }

  Future<void> _saveUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', jsonEncode(user.toJson()));
  }

  Future<void> login(String email, String password) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final data = await ApiService.login(email, password);
      _currentUser = UserModel.fromJson(data['user']);
      await _saveUser(_currentUser!);
      _loading = false;
      notifyListeners();
      await loadChats();
      await loadStories();
    } catch (e) {
      _error = e.toString();
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> register(String email, String password, String name, String username) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final data = await ApiService.register(email, password, name, username);
      _currentUser = UserModel.fromJson(data['user']);
      await _saveUser(_currentUser!);
      _loading = false;
      notifyListeners();
      await loadChats();
    } catch (e) {
      _error = e.toString();
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await ApiService.clearToken();
    _currentUser = null;
    _chats = [];
    _stories = [];
    notifyListeners();
  }

  Future<void> loadChats() async {
    try {
      _chats = await ApiService.getChats();
      notifyListeners();
    } catch (e) {
      debugPrint('loadChats error: $e');
    }
  }

  Future<void> loadStories() async {
    try {
      _stories = await ApiService.getStories();
      notifyListeners();
    } catch (e) {
      debugPrint('loadStories error: $e');
    }
  }

  Future<void> updateProfile(Map<String, dynamic> updates) async {
    try {
      final user = await ApiService.updateProfile(updates);
      _currentUser = user;
      await _saveUser(user);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
