import 'user_model.dart';

class MessageModel {
  final String id;
  final String chatId;
  final String senderId;
  final String text;
  final String type; // text, image, audio, video
  final String? mediaData; // base64
  final int timestamp;
  String status; // sent, read

  MessageModel({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.text,
    required this.type,
    this.mediaData,
    required this.timestamp,
    this.status = 'sent',
  });

  factory MessageModel.fromJson(Map<String, dynamic> json) => MessageModel(
    id: json['id'] ?? '',
    chatId: json['chatId'] ?? '',
    senderId: json['senderId'] ?? '',
    text: json['text'] ?? '',
    type: json['type'] ?? 'text',
    mediaData: json['mediaData'],
    timestamp: json['timestamp'] ?? 0,
    status: json['status'] ?? 'sent',
  );
}

class ChatModel {
  final String id;
  final List<String> participants;
  final String lastMessage;
  final int lastTime;
  final int unreadCount;
  final UserModel partner;

  ChatModel({
    required this.id,
    required this.participants,
    required this.lastMessage,
    required this.lastTime,
    required this.unreadCount,
    required this.partner,
  });

  factory ChatModel.fromJson(Map<String, dynamic> json) => ChatModel(
    id: json['id'] ?? '',
    participants: List<String>.from(json['participants'] ?? []),
    lastMessage: json['lastMessage'] ?? '',
    lastTime: json['lastTime'] ?? 0,
    unreadCount: json['unreadCount'] ?? 0,
    partner: UserModel.fromJson(json['partner'] ?? {}),
  );
}
