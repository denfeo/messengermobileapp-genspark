import 'user_model.dart';

class StoryModel {
  final String id;
  final String userId;
  final String? mediaData;
  final String type; // image, color
  final String text;
  final String color;
  final int timestamp;
  final List<String> viewers;
  final int expiresAt;

  StoryModel({
    required this.id,
    required this.userId,
    this.mediaData,
    required this.type,
    required this.text,
    required this.color,
    required this.timestamp,
    required this.viewers,
    required this.expiresAt,
  });

  factory StoryModel.fromJson(Map<String, dynamic> json) => StoryModel(
    id: json['id'] ?? '',
    userId: json['userId'] ?? '',
    mediaData: json['mediaData'],
    type: json['type'] ?? 'color',
    text: json['text'] ?? '',
    color: json['color'] ?? '#6C5CE7',
    timestamp: json['timestamp'] ?? 0,
    viewers: List<String>.from(json['viewers'] ?? []),
    expiresAt: json['expiresAt'] ?? 0,
  );
}

class StoryGroup {
  final UserModel user;
  final List<StoryModel> stories;
  final bool hasUnviewed;
  final bool isOwn;

  StoryGroup({
    required this.user,
    required this.stories,
    required this.hasUnviewed,
    required this.isOwn,
  });

  factory StoryGroup.fromJson(Map<String, dynamic> json) => StoryGroup(
    user: UserModel.fromJson(json['user'] ?? {}),
    stories: (json['stories'] as List? ?? []).map((s) => StoryModel.fromJson(s)).toList(),
    hasUnviewed: json['hasUnviewed'] ?? false,
    isOwn: json['isOwn'] ?? false,
  );
}
