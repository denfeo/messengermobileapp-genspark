class UserModel {
  final String id;
  final String email;
  final String username;
  final String name;
  final String? avatar;
  final String color;
  final String bio;
  final bool? hasStory;
  final bool? hasUnviewedStory;

  UserModel({
    required this.id,
    required this.email,
    required this.username,
    required this.name,
    this.avatar,
    required this.color,
    this.bio = '',
    this.hasStory,
    this.hasUnviewedStory,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'] ?? '',
    email: json['email'] ?? '',
    username: json['username'] ?? '',
    name: json['name'] ?? '',
    avatar: json['avatar'],
    color: json['color'] ?? '#6C5CE7',
    bio: json['bio'] ?? '',
    hasStory: json['hasStory'],
    hasUnviewedStory: json['hasUnviewedStory'],
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'email': email, 'username': username,
    'name': name, 'avatar': avatar, 'color': color, 'bio': bio,
  };

  UserModel copyWith({String? name, String? bio, String? avatar, String? username}) => UserModel(
    id: id, email: email,
    username: username ?? this.username,
    name: name ?? this.name,
    avatar: avatar ?? this.avatar,
    color: color,
    bio: bio ?? this.bio,
    hasStory: hasStory,
    hasUnviewedStory: hasUnviewedStory,
  );
}
