// Re-export from chat_model.dart for cleaner imports
export 'chat_model.dart' show MessageModel;
