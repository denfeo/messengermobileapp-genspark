import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../models/user_model.dart';

class UserAvatar extends StatelessWidget {
  final UserModel? user;
  final String? name;
  final String? color;
  final String? avatar;
  final double size;
  final bool showStoryRing;
  final bool hasUnviewedStory;

  const UserAvatar({
    super.key,
    this.user,
    this.name,
    this.color,
    this.avatar,
    this.size = 48,
    this.showStoryRing = false,
    this.hasUnviewedStory = false,
  });

  @override
  Widget build(BuildContext context) {
    final displayName = user?.name ?? name ?? '?';
    final displayColor = user?.color ?? color ?? '#6C5CE7';
    final displayAvatar = user?.avatar ?? avatar;

    Widget avatarWidget;
    if (displayAvatar != null && displayAvatar.isNotEmpty) {
      avatarWidget = CircleAvatar(
        radius: size / 2,
        backgroundImage: NetworkImage(displayAvatar),
        backgroundColor: hexToColor(displayColor),
      );
    } else {
      avatarWidget = CircleAvatar(
        radius: size / 2,
        backgroundColor: hexToColor(displayColor),
        child: Text(
          initials(displayName),
          style: TextStyle(
            color: Colors.white,
            fontSize: size * 0.36,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
        ),
      );
    }

    if (!showStoryRing) return avatarWidget;

    return Container(
      width: size + 4,
      height: size + 4,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: hasUnviewedStory
            ? AppTheme.storyGradient
            : const LinearGradient(colors: [Color(0xFFCCCCCC), Color(0xFFAAAAAA)]),
      ),
      padding: const EdgeInsets.all(2),
      child: avatarWidget,
    );
  }
}
