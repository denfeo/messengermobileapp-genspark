import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/chat_model.dart';
import '../models/story_model.dart';

class ApiService {
  static const String baseUrl = 'https://3000-il7cqodjmmvcvq4tn39u1-b237eb32.sandbox.novita.ai/api';
  static String? _token;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
  }

  static Future<void> saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  static Future<void> clearToken() async {
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('current_user');
  }

  static Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_token != null) 'Authorization': 'Bearer $_token',
  };

  static Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    final r = await http.post(Uri.parse('$baseUrl$path'), headers: _headers, body: jsonEncode(body));
    final data = jsonDecode(r.body);
    if (r.statusCode >= 400) throw data['error'] ?? 'Request failed';
    return data;
  }

  static Future<dynamic> _get(String path) async {
    final r = await http.get(Uri.parse('$baseUrl$path'), headers: _headers);
    if (r.statusCode >= 400) {
      final data = jsonDecode(r.body);
      throw data['error'] ?? 'Request failed';
    }
    return jsonDecode(r.body);
  }

  static Future<dynamic> _put(String path, Map<String, dynamic> body) async {
    final r = await http.put(Uri.parse('$baseUrl$path'), headers: _headers, body: jsonEncode(body));
    final data = jsonDecode(r.body);
    if (r.statusCode >= 400) throw data['error'] ?? 'Request failed';
    return data;
  }

  // Auth
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final data = await _post('/auth/login', {'email': email, 'password': password});
    await saveToken(data['token']);
    return data;
  }

  static Future<Map<String, dynamic>> register(String email, String password, String name, String username) async {
    final data = await _post('/auth/register', {'email': email, 'password': password, 'name': name, 'username': username});
    await saveToken(data['token']);
    return data;
  }

  static Future<UserModel> getMe() async {
    final data = await _get('/auth/me');
    return UserModel.fromJson(data);
  }

  // Users
  static Future<List<UserModel>> searchUsers(String query) async {
    final data = await _get('/users/search?q=${Uri.encodeQueryComponent(query)}');
    return (data as List).map((u) => UserModel.fromJson(u)).toList();
  }

  static Future<UserModel> updateProfile(Map<String, dynamic> updates) async {
    final data = await _put('/users/profile', updates);
    return UserModel.fromJson(data);
  }

  // Chats
  static Future<List<ChatModel>> getChats() async {
    final data = await _get('/chats');
    return (data as List).map((c) => ChatModel.fromJson(c)).toList();
  }

  static Future<ChatModel> createChat(String partnerId) async {
    final data = await _post('/chats', {'partnerId': partnerId});
    return ChatModel.fromJson(data);
  }

  // Messages
  static Future<List<MessageModel>> getMessages(String chatId) async {
    final data = await _get('/messages/$chatId');
    return (data as List).map((m) => MessageModel.fromJson(m)).toList();
  }

  static Future<MessageModel> sendMessage(String chatId, {String? text, String type = 'text', String? mediaData}) async {
    final data = await _post('/messages', {
      'chatId': chatId,
      'text': text ?? '',
      'type': type,
      if (mediaData != null) 'mediaData': mediaData,
    });
    return MessageModel.fromJson(data);
  }

  static Future<List<MessageModel>> pollMessages(String chatId, int since) async {
    final data = await _get('/messages/$chatId/poll?since=$since');
    return (data as List).map((m) => MessageModel.fromJson(m)).toList();
  }

  // Typing
  static Future<void> setTyping(String chatId, bool isTyping) async {
    await _post('/chats/$chatId/typing', {'isTyping': isTyping});
  }

  static Future<List<String>> getTyping(String chatId) async {
    final data = await _get('/chats/$chatId/typing');
    return List<String>.from(data['typing'] ?? []);
  }

  // Stories
  static Future<List<StoryGroup>> getStories() async {
    final data = await _get('/stories');
    return (data as List).map((s) => StoryGroup.fromJson(s)).toList();
  }

  static Future<StoryModel> createStory({String? mediaData, String type = 'color', String? text, String? color}) async {
    final data = await _post('/stories', {
      if (mediaData != null) 'mediaData': mediaData,
      'type': type,
      'text': text ?? '',
      'color': color ?? '#6C5CE7',
    });
    return StoryModel.fromJson(data);
  }

  static Future<void> viewStory(String storyId) async {
    await _post('/stories/$storyId/view', {});
  }
}
