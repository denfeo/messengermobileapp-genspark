import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/chat_model.dart';
import '../utils/theme.dart';
import '../widgets/user_avatar.dart';
import 'chat_screen.dart';
import 'story_screen.dart';
import 'search_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  int _tabIndex = 0;
  Timer? _refreshTimer;
  bool _showNewMenu = false;
  late AnimationController _menuAnimCtrl;
  late Animation<double> _menuAnim;

  @override
  void initState() {
    super.initState();
    _menuAnimCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 200));
    _menuAnim = CurvedAnimation(parent: _menuAnimCtrl, curve: Curves.easeOut);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
      _startPolling();
    });
  }

  void _startPolling() {
    _refreshTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) {
        context.read<AppProvider>().loadChats();
      }
    });
  }

  Future<void> _loadData() async {
    final prov = context.read<AppProvider>();
    await prov.loadChats();
    await prov.loadStories();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _menuAnimCtrl.dispose();
    super.dispose();
  }

  void _toggleMenu() {
    setState(() => _showNewMenu = !_showNewMenu);
    if (_showNewMenu) {
      _menuAnimCtrl.forward();
    } else {
      _menuAnimCtrl.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppTheme.backgroundDark : AppTheme.background,
      body: Stack(
        children: [
          IndexedStack(
            index: _tabIndex,
            children: [
              _ChatsTab(onMenuTap: _toggleMenu),
              const SearchScreen(),
              const ProfileScreen(),
            ],
          ),
          if (_showNewMenu) _buildNewMenu(isDark),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(isDark),
    );
  }

  Widget _buildNewMenu(bool isDark) {
    return Positioned.fill(
      child: GestureDetector(
        onTap: _toggleMenu,
        child: Container(
          color: Colors.black.withValues(alpha: 0.5),
          child: Align(
            alignment: Alignment.bottomCenter,
            child: FadeTransition(
              opacity: _menuAnim,
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(_menuAnim),
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: isDark ? AppTheme.surfaceDark : Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 20)],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _menuItem(Icons.chat_outlined, 'New Chat', 'Send a message to your contact', () {
                        _toggleMenu();
                        setState(() => _tabIndex = 1);
                      }),
                      Divider(height: 1, color: isDark ? Colors.white12 : Colors.grey.shade100),
                      _menuItem(Icons.person_add_outlined, 'New Contact', 'Search by @username', () {
                        _toggleMenu();
                        setState(() => _tabIndex = 1);
                      }),
                      Divider(height: 1, color: isDark ? Colors.white12 : Colors.grey.shade100),
                      _menuItem(Icons.groups_outlined, 'Add Story', 'Share a moment with contacts', () {
                        _toggleMenu();
                        _openStoryCreator();
                      }),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        child: TextButton(
                          onPressed: _toggleMenu,
                          style: TextButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
                          child: const Text('Cancel', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _menuItem(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color: AppTheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppTheme.primary, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      onTap: onTap,
    );
  }

  void _openStoryCreator() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const StoryCreatorSheet(),
    );
  }

  Widget _buildBottomNav(bool isDark) {
    final prov = context.watch<AppProvider>();
    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : Colors.white,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 20, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: [
              _navItem(Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded, 'Chats', 0, prov.totalUnread),
              _navCenter(),
              _navItem(Icons.person_rounded, Icons.person_outline_rounded, 'Profile', 2, 0),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData active, IconData inactive, String label, int idx, int badge) {
    final selected = _tabIndex == idx;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tabIndex = idx),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.primary.withValues(alpha: 0.12) : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    selected ? active : inactive,
                    color: selected ? AppTheme.primary : (isDark ? Colors.white38 : Colors.grey),
                    size: 24,
                  ),
                ),
                if (badge > 0)
                  Positioned(
                    right: 2, top: 2,
                    child: Container(
                      width: 16, height: 16,
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      child: Center(child: Text(badge > 9 ? '9+' : '$badge', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800))),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 11, fontWeight: selected ? FontWeight.w600 : FontWeight.w400, color: selected ? AppTheme.primary : (isDark ? Colors.white38 : Colors.grey))),
          ],
        ),
      ),
    );
  }

  Widget _navCenter() {
    return GestureDetector(
      onTap: _toggleMenu,
      child: Container(
        width: 52, height: 52,
        margin: const EdgeInsets.only(bottom: 2),
        decoration: BoxDecoration(
          gradient: AppTheme.storyGradient,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: AppTheme.primary.withValues(alpha: 0.4), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: const Icon(Icons.add_rounded, color: Colors.white, size: 26),
      ),
    );
  }
}

class _ChatsTab extends StatelessWidget {
  final VoidCallback onMenuTap;
  const _ChatsTab({required this.onMenuTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Consumer<AppProvider>(
      builder: (ctx, prov, _) {
        final user = prov.currentUser;
        return CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              snap: true,
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hi, ${user?.name.split(' ').first ?? ''}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                  if (prov.totalUnread > 0)
                    Text('${prov.totalUnread} unread messages', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary, fontWeight: FontWeight.w400)),
                ],
              ),
              actions: [
                Container(
                  margin: const EdgeInsets.only(right: 16),
                  child: Stack(
                    children: [
                      GestureDetector(
                        onTap: () {},
                        child: UserAvatar(user: user, size: 36),
                      ),
                      if (prov.totalUnread > 0)
                        Positioned(
                          right: 0, top: 0,
                          child: Container(
                            width: 10, height: 10,
                            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            // Stories
            SliverToBoxAdapter(child: _StoriesRow()),
            // Chats header
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 8, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Chats', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                    IconButton(
                      onPressed: onMenuTap,
                      icon: Icon(Icons.more_horiz, color: isDark ? Colors.white54 : AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
            // Chat list
            if (prov.chats.isEmpty)
              SliverFillRemaining(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.chat_bubble_outline, size: 64, color: isDark ? Colors.white24 : Colors.grey.shade300),
                      const SizedBox(height: 16),
                      Text('No chats yet', style: TextStyle(color: isDark ? Colors.white38 : AppTheme.textSecondary, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text('Tap + to start a new conversation', style: TextStyle(color: isDark ? Colors.white24 : Colors.grey.shade400, fontSize: 13)),
                    ],
                  ),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) => _ChatTile(chat: prov.chats[i]),
                  childCount: prov.chats.length,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _StoriesRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = context.watch<AppProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: prov.stories.length + 1,
        itemBuilder: (ctx, i) {
          if (i == 0) {
            // Add story button
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
              child: GestureDetector(
                onTap: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (_) => const StoryCreatorSheet(),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 58, height: 58,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: isDark ? Colors.white24 : Colors.grey.shade200, width: 2),
                      ),
                      child: Center(
                        child: Icon(Icons.add_circle_outline, color: AppTheme.primary, size: 28),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('Add Story', style: TextStyle(fontSize: 11, color: isDark ? Colors.white54 : AppTheme.textSecondary)),
                  ],
                ),
              ),
            );
          }
          final group = prov.stories[i - 1];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewerScreen(group: group))),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  UserAvatar(
                    user: group.user,
                    size: 58,
                    showStoryRing: true,
                    hasUnviewedStory: group.hasUnviewed,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    group.user.name.split(' ').first,
                    style: TextStyle(fontSize: 11, color: isDark ? Colors.white70 : AppTheme.textPrimary, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final ChatModel chat;
  const _ChatTile({required this.chat});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: () => Navigator.push(context, PageRouteBuilder(
        pageBuilder: (_, a, __) => ChatScreen(chat: chat),
        transitionsBuilder: (_, a, __, c) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: c,
        ),
      )),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(
          children: [
            UserAvatar(
              user: chat.partner,
              size: 54,
              showStoryRing: chat.partner.hasStory == true,
              hasUnviewedStory: chat.partner.hasUnviewedStory == true,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          chat.partner.name,
                          style: TextStyle(fontWeight: chat.unreadCount > 0 ? FontWeight.w700 : FontWeight.w600, fontSize: 15),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(formatTime(chat.lastTime), style: TextStyle(fontSize: 12, color: chat.unreadCount > 0 ? AppTheme.primary : (isDark ? Colors.white38 : AppTheme.textSecondary), fontWeight: chat.unreadCount > 0 ? FontWeight.w600 : FontWeight.w400)),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          chat.lastMessage,
                          style: TextStyle(fontSize: 13, color: chat.unreadCount > 0 ? (isDark ? Colors.white70 : AppTheme.textPrimary) : (isDark ? Colors.white38 : AppTheme.textSecondary), fontWeight: chat.unreadCount > 0 ? FontWeight.w500 : FontWeight.w400),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (chat.unreadCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(10)),
                          child: Text('${chat.unreadCount}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
