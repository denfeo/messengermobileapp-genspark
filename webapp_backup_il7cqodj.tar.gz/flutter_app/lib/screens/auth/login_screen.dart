import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../utils/theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController(text: 'demo@smartchat.com');
  final _passCtrl = TextEditingController(text: 'demo123');
  bool _obscure = true;
  bool _isRegister = false;
  final _nameCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _nameCtrl.dispose();
    _usernameCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final prov = context.read<AppProvider>();
    if (_isRegister) {
      await prov.register(_emailCtrl.text.trim(), _passCtrl.text, _nameCtrl.text.trim(), _usernameCtrl.text.trim());
    } else {
      await prov.login(_emailCtrl.text.trim(), _passCtrl.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: Consumer<AppProvider>(
          builder: (ctx, prov, _) {
            if (prov.loading) {
              return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
            }
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 32),
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        gradient: AppTheme.storyGradient,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 32),
                    ),
                    const SizedBox(height: 28),
                    Text(
                      _isRegister ? 'Create Account' : 'Welcome back',
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -0.5),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _isRegister ? 'Join SmartChat today' : 'Sign in to SmartChat',
                      style: TextStyle(fontSize: 15, color: isDark ? Colors.white54 : AppTheme.textSecondary),
                    ),
                    if (prov.error != null) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red, size: 18),
                            const SizedBox(width: 8),
                            Expanded(child: Text(prov.error!, style: const TextStyle(color: Colors.red, fontSize: 13))),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 32),
                    if (_isRegister) ...[
                      TextFormField(
                        controller: _nameCtrl,
                        decoration: const InputDecoration(hintText: 'Full Name', prefixIcon: Icon(Icons.person_outline)),
                        validator: (v) => v!.isEmpty ? 'Enter your name' : null,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _usernameCtrl,
                        decoration: const InputDecoration(hintText: '@username', prefixIcon: Icon(Icons.alternate_email)),
                        validator: (v) => v!.isEmpty ? 'Enter username' : null,
                      ),
                      const SizedBox(height: 14),
                    ],
                    TextFormField(
                      controller: _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(hintText: 'Email address', prefixIcon: Icon(Icons.email_outlined)),
                      validator: (v) => !v!.contains('@') ? 'Enter valid email' : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _passCtrl,
                      obscureText: _obscure,
                      decoration: InputDecoration(
                        hintText: 'Password',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _obscure = !_obscure),
                          icon: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                        ),
                      ),
                      validator: (v) => v!.length < 6 ? 'Min 6 characters' : null,
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: _submit,
                      child: Text(_isRegister ? 'Create Account' : 'Sign In'),
                    ),
                    const SizedBox(height: 16),
                    if (!_isRegister) ...[
                      OutlinedButton(
                        onPressed: () async {
                          _emailCtrl.text = 'demo@smartchat.com';
                          _passCtrl.text = 'demo123';
                          await _submit();
                        },
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 52),
                          side: const BorderSide(color: AppTheme.primary),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.play_circle_outline, color: AppTheme.primary),
                            SizedBox(width: 8),
                            Text('Try Demo', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    Center(
                      child: TextButton(
                        onPressed: () {
                          prov.clearError();
                          setState(() => _isRegister = !_isRegister);
                        },
                        child: RichText(
                          text: TextSpan(
                            style: TextStyle(fontSize: 14, color: isDark ? Colors.white54 : AppTheme.textSecondary),
                            children: [
                              TextSpan(text: _isRegister ? 'Already have an account? ' : "Don't have an account? "),
                              TextSpan(
                                text: _isRegister ? 'Sign in' : 'Sign up',
                                style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
