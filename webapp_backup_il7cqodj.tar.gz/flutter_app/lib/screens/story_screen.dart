import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/story_model.dart';
import '../providers/app_provider.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';
import '../widgets/user_avatar.dart';

class StoryViewerScreen extends StatefulWidget {
  final StoryGroup group;
  const StoryViewerScreen({super.key, required this.group});

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen> with SingleTickerProviderStateMixin {
  late AnimationController _progressCtrl;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _progressCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 5));
    _startStory(0);
  }

  void _startStory(int index) {
    setState(() => _currentIndex = index);
    _progressCtrl.reset();
    _progressCtrl.forward().then((_) {
      if (_currentIndex < widget.group.stories.length - 1) {
        _startStory(_currentIndex + 1);
      } else {
        Navigator.pop(context);
      }
    });
    // Mark as viewed
    final story = widget.group.stories[index];
    ApiService.viewStory(story.id);
  }

  void _onTap(bool isRight) {
    if (isRight && _currentIndex < widget.group.stories.length - 1) {
      _startStory(_currentIndex + 1);
    } else if (!isRight && _currentIndex > 0) {
      _startStory(_currentIndex - 1);
    } else if (!isRight) {
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _progressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.group.stories[_currentIndex];
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          _onTap(d.globalPosition.dx > w / 2);
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Story content
            _buildStoryContent(story),
            // Overlay gradient
            Positioned(
              top: 0, left: 0, right: 0,
              height: 150,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.black.withValues(alpha: 0.6), Colors.transparent],
                  ),
                ),
              ),
            ),
            // Progress bars
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 12, right: 12,
              child: Row(
                children: widget.group.stories.asMap().entries.map((e) {
                  return Expanded(
                    child: Container(
                      height: 2.5,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: LinearProgressIndicator(
                          value: e.key < _currentIndex
                              ? 1
                              : e.key == _currentIndex
                                  ? null
                                  : 0,
                          backgroundColor: Colors.white.withValues(alpha: 0.35),
                          valueColor: const AlwaysStoppedAnimation(Colors.white),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            // User info
            Positioned(
              top: MediaQuery.of(context).padding.top + 20,
              left: 12, right: 12,
              child: Row(
                children: [
                  UserAvatar(user: widget.group.user, size: 38),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.group.user.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                        Text(formatTime(story.timestamp), style: const TextStyle(color: Colors.white70, fontSize: 11)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryContent(StoryModel story) {
    if (story.mediaData != null) {
      return Image.memory(base64Decode(story.mediaData!), fit: BoxFit.cover);
    }
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [hexToColor(story.color), hexToColor(story.color).withValues(alpha: 0.6)],
        ),
      ),
      child: Center(
        child: story.text.isNotEmpty
            ? Text(story.text, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700), textAlign: TextAlign.center)
            : Icon(Icons.auto_awesome, color: Colors.white.withValues(alpha: 0.7), size: 80),
      ),
    );
  }
}

class StoryCreatorSheet extends StatefulWidget {
  const StoryCreatorSheet({super.key});
  @override
  State<StoryCreatorSheet> createState() => _StoryCreatorSheetState();
}

class _StoryCreatorSheetState extends State<StoryCreatorSheet> {
  String? _mediaData;
  final _textCtrl = TextEditingController();
  String _selectedColor = '#6C5CE7';
  bool _sending = false;
  static const colors = ['#6C5CE7','#FF6B6B','#4ECDC4','#FF9F43','#A29BFE','#FD79A8','#00B894','#E17055'];

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 60);
    if (file == null) return;
    if (kIsWeb) {
      final bytes = await file.readAsBytes();
      setState(() => _mediaData = base64Encode(bytes));
    } else {
      final bytes = await File(file.path).readAsBytes();
      setState(() => _mediaData = base64Encode(bytes));
    }
  }

  Future<void> _send() async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await ApiService.createStory(
        mediaData: _mediaData,
        type: _mediaData != null ? 'image' : 'color',
        text: _textCtrl.text.trim(),
        color: _selectedColor,
      );
      await context.read<AppProvider>().loadStories();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 8),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Create Story', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                TextButton(
                  onPressed: _sending ? null : _send,
                  child: _sending
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.primary))
                      : const Text('Share', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _pickImage,
                    child: Container(
                      width: double.infinity, height: 200,
                      decoration: BoxDecoration(
                        color: _mediaData == null ? hexToColor(_selectedColor).withValues(alpha: 0.15) : null,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: hexToColor(_selectedColor).withValues(alpha: 0.4), width: 2, style: BorderStyle.solid),
                        image: _mediaData != null
                            ? DecorationImage(image: MemoryImage(base64Decode(_mediaData!)), fit: BoxFit.cover)
                            : null,
                      ),
                      child: _mediaData == null
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_photo_alternate_outlined, size: 48, color: hexToColor(_selectedColor)),
                                const SizedBox(height: 8),
                                Text('Tap to add photo', style: TextStyle(color: hexToColor(_selectedColor), fontWeight: FontWeight.w500)),
                              ],
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _textCtrl,
                    decoration: const InputDecoration(hintText: 'Add a caption...'),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: colors.map((c) => GestureDetector(
                      onTap: () => setState(() => _selectedColor = c),
                      child: Container(
                        width: 32, height: 32,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: hexToColor(c),
                          shape: BoxShape.circle,
                          border: _selectedColor == c ? Border.all(color: Colors.white, width: 3) : null,
                          boxShadow: _selectedColor == c ? [BoxShadow(color: hexToColor(c).withValues(alpha: 0.5), blurRadius: 6)] : null,
                        ),
                      ),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
