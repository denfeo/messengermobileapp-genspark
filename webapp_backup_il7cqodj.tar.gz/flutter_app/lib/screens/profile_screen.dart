import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../utils/theme.dart';
import '../main.dart' show ThemeProvider;
import '../widgets/user_avatar.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isEditing = false;
  final _nameCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = context.read<AppProvider>().currentUser;
      if (user != null) {
        _nameCtrl.text = user.name;
        _bioCtrl.text = user.bio;
        _usernameCtrl.text = user.username;
      }
    });
  }

  Future<void> _pickAvatar() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (file == null) return;
    String data;
    if (kIsWeb) {
      final bytes = await file.readAsBytes();
      data = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    } else {
      final bytes = await File(file.path).readAsBytes();
      data = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    }
    await context.read<AppProvider>().updateProfile({'avatar': data});
  }

  Future<void> _saveProfile() async {
    await context.read<AppProvider>().updateProfile({
      'name': _nameCtrl.text.trim(),
      'bio': _bioCtrl.text.trim(),
      'username': _usernameCtrl.text.trim(),
    });
    setState(() => _isEditing = false);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Consumer<AppProvider>(
      builder: (ctx, prov, _) {
        final user = prov.currentUser;
        if (user == null) return const SizedBox();
        return Scaffold(
          appBar: AppBar(
            title: const Text('Profile'),
            automaticallyImplyLeading: false,
            actions: [
              if (_isEditing)
                TextButton(
                  onPressed: _saveProfile,
                  child: const Text('Save', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                )
              else
                IconButton(
                  onPressed: () => setState(() => _isEditing = true),
                  icon: const Icon(Icons.edit_outlined),
                ),
            ],
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 24),
                // Avatar
                Center(
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: AppTheme.primary.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 6))],
                        ),
                        child: _buildAvatarWidget(user),
                      ),
                      if (_isEditing)
                        Positioned(
                          bottom: 2, right: 2,
                          child: GestureDetector(
                            onTap: _pickAvatar,
                            child: Container(
                              width: 28, height: 28,
                              decoration: const BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
                              child: const Icon(Icons.camera_alt, color: Colors.white, size: 16),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (!_isEditing) ...[
                  Text(user.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                  const SizedBox(height: 4),
                  Text('@${user.username}', style: const TextStyle(fontSize: 15, color: AppTheme.primary, fontWeight: FontWeight.w500)),
                  if (user.bio.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(user.bio, style: TextStyle(fontSize: 14, color: isDark ? Colors.white54 : AppTheme.textSecondary), textAlign: TextAlign.center),
                    ),
                  ],
                  const SizedBox(height: 24),
                  // Stats row
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _statItem('${context.watch<AppProvider>().chats.length}', 'Chats'),
                        Container(width: 1, height: 40, color: isDark ? Colors.white12 : Colors.grey.shade200),
                        _statItem('@${user.username}', 'Username'),
                        Container(width: 1, height: 40, color: isDark ? Colors.white12 : Colors.grey.shade200),
                        _statItem(user.email.split('@').first, 'Email'),
                      ],
                    ),
                  ),
                ] else ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        TextField(
                          controller: _nameCtrl,
                          decoration: const InputDecoration(labelText: 'Full Name', prefixIcon: Icon(Icons.person_outline)),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _usernameCtrl,
                          decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.alternate_email)),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _bioCtrl,
                          maxLines: 3,
                          decoration: const InputDecoration(labelText: 'Bio', prefixIcon: Icon(Icons.info_outline), alignLabelWithHint: true),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 32),
                // Settings
                _buildSection([
                  _settingTile(Icons.dark_mode_outlined, 'Dark Mode', trailing: Switch.adaptive(
                    value: isDark,
                    onChanged: (v) {
                      context.read<ThemeProvider>().toggle();
                    },
                  )),
                  _settingTile(Icons.notifications_outlined, 'Notifications', onTap: () {}),
                  _settingTile(Icons.privacy_tip_outlined, 'Privacy', onTap: () {}),
                  _settingTile(Icons.help_outline, 'Help', onTap: () {}),
                ]),
                const SizedBox(height: 16),
                _buildSection([
                  _settingTile(Icons.logout, 'Sign Out', color: Colors.red, onTap: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Sign Out'),
                        content: const Text('Are you sure you want to sign out?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sign Out', style: TextStyle(color: Colors.red))),
                        ],
                      ),
                    );
                    if (confirmed == true) context.read<AppProvider>().logout();
                  }),
                ]),
                const SizedBox(height: 32),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildAvatarWidget(dynamic user) {
    if (user.avatar != null && user.avatar!.startsWith('data:')) {
      final base64Data = user.avatar!.split(',').last;
      return CircleAvatar(
        radius: 52,
        backgroundImage: MemoryImage(base64Decode(base64Data)),
        backgroundColor: hexToColor(user.color),
      );
    }
    return UserAvatar(user: user, size: 104);
  }

  Widget _statItem(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: -0.3), maxLines: 1, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
      ],
    );
  }

  Widget _buildSection(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(children: children),
    );
  }

  Widget _settingTile(IconData icon, String label, {Color? color, VoidCallback? onTap, Widget? trailing}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ListTile(
      leading: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          color: (color ?? AppTheme.primary).withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color ?? AppTheme.primary, size: 20),
      ),
      title: Text(label, style: TextStyle(fontWeight: FontWeight.w500, color: color)),
      trailing: trailing ?? (onTap != null ? Icon(Icons.chevron_right, color: isDark ? Colors.white38 : Colors.grey.shade400) : null),
      onTap: onTap,
    );
  }
}
