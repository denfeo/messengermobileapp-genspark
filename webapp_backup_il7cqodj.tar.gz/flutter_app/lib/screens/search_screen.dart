import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/user_model.dart';
import '../utils/theme.dart';
import '../widgets/user_avatar.dart';
import 'chat_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  List<UserModel> _results = [];
  bool _searching = false;
  String _lastQuery = '';

  Future<void> _search(String q) async {
    if (q.trim() == _lastQuery) return;
    _lastQuery = q.trim();
    if (q.trim().isEmpty) {
      setState(() { _results = []; _searching = false; });
      return;
    }
    setState(() => _searching = true);
    try {
      final r = await ApiService.searchUsers(q.trim());
      if (mounted) setState(() { _results = r; _searching = false; });
    } catch (_) {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _openChat(UserModel user) async {
    try {
      final chat = await ApiService.createChat(user.id);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chat: chat)));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search'),
        automaticallyImplyLeading: false,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _ctrl,
              autofocus: false,
              onChanged: _search,
              decoration: InputDecoration(
                hintText: 'Search by @username or name...',
                prefixIcon: const Icon(Icons.search, color: AppTheme.primary),
                suffixIcon: _ctrl.text.isNotEmpty
                    ? IconButton(onPressed: () { _ctrl.clear(); _search(''); }, icon: const Icon(Icons.clear))
                    : null,
              ),
            ),
          ),
        ),
      ),
      body: _searching
          ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
          : _results.isEmpty && _ctrl.text.trim().isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search, size: 72, color: isDark ? Colors.white24 : Colors.grey.shade200),
                      const SizedBox(height: 16),
                      Text('Find people on SmartChat', style: TextStyle(color: isDark ? Colors.white38 : AppTheme.textSecondary, fontSize: 16)),
                      const SizedBox(height: 6),
                      Text('Search by name or @username', style: TextStyle(color: isDark ? Colors.white24 : Colors.grey.shade400, fontSize: 13)),
                    ],
                  ),
                )
              : _results.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.person_search, size: 64, color: isDark ? Colors.white24 : Colors.grey.shade300),
                          const SizedBox(height: 12),
                          Text('No users found', style: TextStyle(color: isDark ? Colors.white38 : AppTheme.textSecondary)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: _results.length,
                      padding: const EdgeInsets.all(8),
                      itemBuilder: (ctx, i) {
                        final u = _results[i];
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                          child: ListTile(
                            leading: UserAvatar(user: u, size: 46),
                            title: Text(u.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                            subtitle: Text('@${u.username}', style: const TextStyle(color: AppTheme.primary, fontSize: 13)),
                            trailing: ElevatedButton(
                              onPressed: () => _openChat(u),
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size(72, 34),
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                backgroundColor: AppTheme.primary,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                              ),
                              child: const Text('Chat', style: TextStyle(fontSize: 13)),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
