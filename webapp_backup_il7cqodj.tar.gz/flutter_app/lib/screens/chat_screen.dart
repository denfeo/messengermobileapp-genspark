import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart' as msg_models;
import '../providers/app_provider.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';
import '../widgets/user_avatar.dart';

class ChatScreen extends StatefulWidget {
  final ChatModel chat;
  const ChatScreen({super.key, required this.chat});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();
  List<msg_models.MessageModel> _messages = [];
  bool _loading = true;
  bool _partnerTyping = false;
  Timer? _pollTimer;
  Timer? _typingTimer;
  int _lastMessageTs = 0;
  bool _isRecording = false;
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  String? _recordingPath;
  int _recordingDuration = 0;
  Timer? _recordingTimer;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _startPolling();
    _textCtrl.addListener(_onTypingChanged);
  }

  Future<void> _loadMessages() async {
    try {
      final messages = await ApiService.getMessages(widget.chat.id);
      setState(() {
        _messages = messages;
        _loading = false;
        if (messages.isNotEmpty) _lastMessageTs = messages.last.timestamp;
      });
      _scrollToBottom();
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      if (!mounted) return;
      try {
        final newMsgs = await ApiService.pollMessages(widget.chat.id, _lastMessageTs);
        if (newMsgs.isNotEmpty) {
          setState(() {
            _messages.addAll(newMsgs);
            _lastMessageTs = newMsgs.last.timestamp;
          });
          _scrollToBottom();
        }
        final typing = await ApiService.getTyping(widget.chat.id);
        final wasTyping = _partnerTyping;
        setState(() => _partnerTyping = typing.contains(widget.chat.partner.id));
        if (!wasTyping && _partnerTyping) _scrollToBottom();
      } catch (_) {}
    });
  }

  void _onTypingChanged() {
    ApiService.setTyping(widget.chat.id, _textCtrl.text.isNotEmpty);
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 3), () {
      ApiService.setTyping(widget.chat.id, false);
    });
  }

  void _scrollToBottom({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: animated ? const Duration(milliseconds: 300) : Duration.zero,
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendText() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty) return;
    _textCtrl.clear();
    ApiService.setTyping(widget.chat.id, false);
    try {
      final msg = await ApiService.sendMessage(widget.chat.id, text: text, type: 'text');
      setState(() {
        _messages.add(msg);
        _lastMessageTs = msg.timestamp;
      });
      _scrollToBottom();
      if (mounted) context.read<AppProvider>().loadChats();
    } catch (_) {}
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (file == null) return;
    try {
      String mediaData;
      if (kIsWeb) {
        final bytes = await file.readAsBytes();
        mediaData = base64Encode(bytes);
      } else {
        final bytes = await File(file.path).readAsBytes();
        mediaData = base64Encode(bytes);
      }
      final msg = await ApiService.sendMessage(widget.chat.id, type: 'image', mediaData: mediaData);
      setState(() {
        _messages.add(msg);
        _lastMessageTs = msg.timestamp;
      });
      _scrollToBottom();
      context.read<AppProvider>().loadChats();
    } catch (e) {
      debugPrint('Send image error: $e');
    }
  }

  Future<void> _startRecording() async {
    if (kIsWeb) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Voice recording available on mobile')));
      return;
    }
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;
    final dir = await getTemporaryDirectory();
    _recordingPath = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: _recordingPath!);
    setState(() {
      _isRecording = true;
      _recordingDuration = 0;
    });
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _recordingDuration++);
    });
  }

  Future<void> _stopRecording({bool cancel = false}) async {
    _recordingTimer?.cancel();
    final path = await _recorder.stop();
    setState(() => _isRecording = false);
    if (cancel || path == null) return;
    try {
      final bytes = await File(path).readAsBytes();
      final mediaData = base64Encode(bytes);
      final msg = await ApiService.sendMessage(widget.chat.id, type: 'audio', mediaData: mediaData);
      setState(() {
        _messages.add(msg);
        _lastMessageTs = msg.timestamp;
      });
      _scrollToBottom();
      context.read<AppProvider>().loadChats();
    } catch (e) {
      debugPrint('Send audio error: $e');
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _typingTimer?.cancel();
    _recordingTimer?.cancel();
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    _recorder.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final me = context.watch<AppProvider>().currentUser;
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 40,
        title: Row(
          children: [
            UserAvatar(user: widget.chat.partner, size: 38),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.chat.partner.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  if (_partnerTyping)
                    const Text('typing...', style: TextStyle(fontSize: 12, color: AppTheme.primary, fontWeight: FontWeight.w400))
                  else
                    Text('@${widget.chat.partner.username}', style: TextStyle(fontSize: 12, color: isDark ? Colors.white38 : AppTheme.textSecondary, fontWeight: FontWeight.w400)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.videocam_outlined), onPressed: () {}),
          IconButton(icon: const Icon(Icons.call_outlined), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
                : _messages.isEmpty
                    ? Center(child: Text('Say hi to ${widget.chat.partner.name.split(' ').first}! 👋', style: TextStyle(color: isDark ? Colors.white38 : AppTheme.textSecondary)))
                    : ListView.builder(
                        controller: _scrollCtrl,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        itemCount: _messages.length + (_partnerTyping ? 1 : 0),
                        itemBuilder: (ctx, i) {
                          if (i == _messages.length) return _TypingBubble(partner: widget.chat.partner);
                          final m = _messages[i];
                          return _MessageBubble(
                            message: m,
                            isMe: m.senderId == me?.id,
                            audioPlayer: _audioPlayer,
                          );
                        },
                      ),
          ),
          _buildInputBar(isDark),
        ],
      ),
    );
  }

  Widget _buildInputBar(bool isDark) {
    if (_isRecording) {
      return Container(
        padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: MediaQuery.of(context).padding.bottom + 12),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.surfaceDark : Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, -2))],
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => _stopRecording(cancel: true),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(Icons.delete_outline, color: Colors.red, size: 22),
              ),
            ),
            Expanded(
              child: Container(
                height: 48,
                margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.mic, color: Colors.red, size: 18),
                    const SizedBox(width: 6),
                    Text(
                      'Recording ${_recordingDuration}s',
                      style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () => _stopRecording(cancel: false),
              child: Container(
                width: 48, height: 48,
                decoration: const BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: EdgeInsets.only(left: 12, right: 12, top: 10, bottom: MediaQuery.of(context).padding.bottom + 10),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : Colors.white,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, -2))],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: _sendImage,
            icon: Icon(Icons.image_outlined, color: isDark ? Colors.white54 : AppTheme.textSecondary),
            padding: const EdgeInsets.all(6),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF2A2A4A) : const Color(0xFFF5F5F5),
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                controller: _textCtrl,
                focusNode: _focusNode,
                maxLines: 4,
                minLines: 1,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: 'Message',
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  hintStyle: TextStyle(color: isDark ? Colors.white38 : Colors.grey),
                ),
                onSubmitted: (_) => _sendText(),
              ),
            ),
          ),
          const SizedBox(width: 6),
          AnimatedBuilder(
            animation: _textCtrl,
            builder: (ctx, _) {
              final hasText = _textCtrl.text.trim().isNotEmpty;
              return GestureDetector(
                onTap: hasText ? _sendText : null,
                onLongPressStart: hasText ? null : (_) => _startRecording(),
                onLongPressEnd: hasText ? null : (_) => _stopRecording(),
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    gradient: hasText ? AppTheme.storyGradient : null,
                    color: hasText ? null : (isDark ? Colors.white12 : const Color(0xFFEEEEEE)),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    hasText ? Icons.send_rounded : Icons.mic_rounded,
                    color: hasText ? Colors.white : (isDark ? Colors.white54 : AppTheme.textSecondary),
                    size: 20,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final msg_models.MessageModel message;
  final bool isMe;
  final AudioPlayer audioPlayer;
  const _MessageBubble({required this.message, required this.isMe, required this.audioPlayer});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: EdgeInsets.only(top: 2, bottom: 2, left: isMe ? 48 : 4, right: isMe ? 4 : 48),
      child: Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          padding: _getPadding(),
          decoration: BoxDecoration(
            color: isMe ? AppTheme.bubbleOut : (isDark ? AppTheme.bubbleInDark : AppTheme.bubbleIn),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(18),
              topRight: const Radius.circular(18),
              bottomLeft: Radius.circular(isMe ? 18 : 4),
              bottomRight: Radius.circular(isMe ? 4 : 18),
            ),
          ),
          child: Column(
            crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildContent(isDark),
              const SizedBox(height: 3),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    formatTime(message.timestamp),
                    style: TextStyle(
                      fontSize: 10,
                      color: isMe ? Colors.white60 : (isDark ? Colors.white38 : AppTheme.textSecondary),
                    ),
                  ),
                  if (isMe) ...[
                    const SizedBox(width: 3),
                    Icon(
                      message.status == 'read' ? Icons.done_all : Icons.done,
                      size: 14,
                      color: message.status == 'read' ? Colors.lightBlueAccent : Colors.white54,
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  EdgeInsets _getPadding() {
    if (message.type == 'image') return const EdgeInsets.all(4);
    if (message.type == 'audio') return const EdgeInsets.symmetric(horizontal: 10, vertical: 8);
    return const EdgeInsets.symmetric(horizontal: 14, vertical: 10);
  }

  Widget _buildContent(bool isDark) {
    switch (message.type) {
      case 'image':
        if (message.mediaData != null) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.memory(
              base64Decode(message.mediaData!),
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
          );
        }
        return const Icon(Icons.image, color: Colors.white, size: 40);
      case 'audio':
        return _AudioBubble(mediaData: message.mediaData, isMe: isMe, audioPlayer: audioPlayer);
      case 'video':
        return _VideoCircle(mediaData: message.mediaData);
      default:
        return Text(
          message.text,
          style: TextStyle(
            color: isMe ? Colors.white : (isDark ? Colors.white : AppTheme.textPrimary),
            fontSize: 14.5,
            height: 1.35,
          ),
        );
    }
  }
}

class _AudioBubble extends StatefulWidget {
  final String? mediaData;
  final bool isMe;
  final AudioPlayer audioPlayer;
  const _AudioBubble({this.mediaData, required this.isMe, required this.audioPlayer});

  @override
  State<_AudioBubble> createState() => _AudioBubbleState();
}

class _AudioBubbleState extends State<_AudioBubble> {
  bool _playing = false;

  Future<void> _toggle() async {
    if (widget.mediaData == null) return;
    if (_playing) {
      await widget.audioPlayer.pause();
      setState(() => _playing = false);
    } else {
      if (!kIsWeb) {
        try {
          final bytes = base64Decode(widget.mediaData!);
          final dir = await getTemporaryDirectory();
          final file = File('${dir.path}/play_${DateTime.now().millisecondsSinceEpoch}.m4a');
          await file.writeAsBytes(bytes);
          await widget.audioPlayer.setFilePath(file.path);
          await widget.audioPlayer.play();
          setState(() => _playing = true);
          widget.audioPlayer.playerStateStream.listen((state) {
            if (state.processingState == ProcessingState.completed) {
              if (mounted) setState(() => _playing = false);
            }
          });
        } catch (e) {
          debugPrint('Audio play error: $e');
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _toggle,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: widget.isMe ? Colors.white.withValues(alpha: 0.25) : AppTheme.primary.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: widget.isMe ? Colors.white : AppTheme.primary, size: 20),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 100, height: 20,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(20, (i) => Container(
                    width: 3,
                    height: (i % 3 == 0 ? 16 : i % 2 == 0 ? 10 : 14).toDouble(),
                    decoration: BoxDecoration(
                      color: widget.isMe ? Colors.white.withValues(alpha: 0.7) : AppTheme.primary.withValues(alpha: 0.6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  )),
                ),
              ),
              const SizedBox(height: 3),
              Text('Voice message', style: TextStyle(fontSize: 11, color: widget.isMe ? Colors.white60 : AppTheme.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }
}

class _VideoCircle extends StatelessWidget {
  final String? mediaData;
  const _VideoCircle({this.mediaData});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160, height: 160,
      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black),
      child: const Center(child: Icon(Icons.play_circle_fill, color: Colors.white, size: 48)),
    );
  }
}

class _TypingBubble extends StatefulWidget {
  final dynamic partner;
  const _TypingBubble({required this.partner});
  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _dot1, _dot2, _dot3;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat();
    _dot1 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.4, curve: Curves.easeInOut)));
    _dot2 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.2, 0.6, curve: Curves.easeInOut)));
    _dot3 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.4, 0.8, curve: Curves.easeInOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, top: 2, bottom: 2, right: 48),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFF1F0FF),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(18), topRight: Radius.circular(18),
              bottomLeft: Radius.circular(4), bottomRight: Radius.circular(18),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _dot(_dot1), const SizedBox(width: 3),
              _dot(_dot2), const SizedBox(width: 3),
              _dot(_dot3),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dot(Animation<double> anim) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, -4 * anim.value),
        child: Container(
          width: 8, height: 8,
          decoration: const BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
        ),
      ),
    );
  }
}
